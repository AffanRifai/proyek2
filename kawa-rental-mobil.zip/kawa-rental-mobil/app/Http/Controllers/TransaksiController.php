<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pembayaran;
use Barryvdh\DomPDF\Facade\Pdf;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Response;

class TransaksiController extends Controller
{
    public function nota($id)
    {
        $pembayaran = Pembayaran::with('booking')->findOrFail($id);
        $verificationUrl = route('transaksi.downloadNota', $pembayaran->id);

        // QR code langsung generate
        $qrcode = QrCode::format('svg')->size(150)->generate($verificationUrl);

        $logoPath = public_path('images/logo.png');

        return view('transaksi.nota', compact('pembayaran', 'qrcode', 'logoPath'));
    }

    public function downloadNota($id)
    {
        $pembayaran = Pembayaran::with('booking')->findOrFail($id);
        $verificationUrl = route('transaksi.downloadNota', $pembayaran->id);
        $qrcode = QrCode::format('svg')->size(150)->generate($verificationUrl);
        $logoPath = public_path('images/logo.png');

        $pdf = Pdf::loadView('transaksi.nota-pdf', compact('pembayaran', 'qrcode', 'logoPath'));
        $filename = 'Nota_Transaksi_' . $pembayaran->booking->id_transaksi . '.pdf';

        return $pdf->download($filename);
    }

    public function downloadNotaGambar($id)
    {
        // Ambil data transaksi (ubah sesuai model kamu)
        $transaksi = \App\Models\Transaksi::findOrFail($id);

        // Generate QR Code (data bisa disesuaikan)
        $qrCode = base64_encode(QrCode::format('png')->size(200)->generate(route('transaksi.show', $id)));

        // Render tampilan Blade ke HTML
        $html = View::make('transaksi.nota', compact('transaksi', 'qrCode'))->render();

        // Simpan HTML ke file temporer
        $path = storage_path('app/public/nota_' . $id . '.html');
        file_put_contents($path, $html);

        // Return sebagai download (bisa juga ubah ke PDF nanti)
        return Response::make($html, 200, [
            'Content-Type' => 'text/html',
            'Content-Disposition' => 'attachment; filename="nota_transaksi_' . $id . '.html"',
        ]);
    }
}
